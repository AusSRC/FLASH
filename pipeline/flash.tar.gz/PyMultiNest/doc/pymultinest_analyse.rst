Analysing the output
=======================================

See also the multinest_marginals*.py scripts.

.. automodule:: pymultinest.analyse
      :members:
