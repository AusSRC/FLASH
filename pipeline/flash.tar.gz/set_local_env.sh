# Set path to FLASH FINDER
export FINDER=/mnt/shared/flash_test/linefinder/ 

# Set path to MULTINEST
export MULTINEST=/mnt/shared/flash_test/PyMultiNest/MultiNest/

# Set path to PYMULTINEST
export PYMULTINEST=/mnt/shared/flash_test/PyMultiNest/

# Add MultiNest library to dynamic library path
export DYLD_LIBRARY_PATH=$MULTINEST/lib:${DYLD_LIBRARY_PATH}
export LD_LIBRARY_PATH=$MULTINEST/lib:${LD_LIBRARY_PATH}

# Set path to Matplotlib set up
#export MATPLOTLIBRC=$HOME/.local/lib/python3.10/site-packages/matplotlib/
